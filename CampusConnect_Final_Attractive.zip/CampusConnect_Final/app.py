from datetime import datetime

from flask import Flask, flash, redirect, render_template, request, session, url_for
import psycopg2
from psycopg2 import IntegrityError
from psycopg2.extras import RealDictCursor
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = "campusconnect-final-2026"

DB = {
    "host": "localhost",
    "database": "campusconnect",
    "user": "postgres",
    "password": "postgres",
    "port": 5432,
}

CATEGORIES = ["Technical", "Sports", "Cultural", "Workshop", "Seminar", "Other"]
CATEGORY_IMAGES = {
    "Technical": "tech.jpg",
    "Sports": "sports.jpg",
    "Cultural": "cultural.jpg",
    "Workshop": "workshop.jpg",
    "Seminar": "seminar.jpg",
    "Other": "other.jpg",
}


def db():
    return psycopg2.connect(**DB)


def q(sql, params=(), one=False):
    conn = db()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute(sql, params)
        result = cur.fetchone() if one else (cur.fetchall() if cur.description else None)
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def setup():
    q("""
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            college_id VARCHAR(60) UNIQUE NOT NULL,
            email VARCHAR(160) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(20) NOT NULL DEFAULT 'student',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    q("""
        CREATE TABLE IF NOT EXISTS events (
            id SERIAL PRIMARY KEY,
            title VARCHAR(160) NOT NULL,
            category VARCHAR(50) NOT NULL,
            short_description VARCHAR(300) NOT NULL,
            description TEXT NOT NULL,
            event_date DATE NOT NULL,
            event_time TIME NOT NULL,
            registration_start TIMESTAMP NOT NULL,
            registration_end TIMESTAMP NOT NULL,
            venue VARCHAR(160) NOT NULL,
            organizer VARCHAR(160) NOT NULL,
            eligibility TEXT,
            rules TEXT,
            instructions TEXT,
            contact_person VARCHAR(120),
            contact_info VARCHAR(160),
            important_notes TEXT,
            created_by INT REFERENCES users(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    q("""
        CREATE TABLE IF NOT EXISTS registrations (
            id SERIAL PRIMARY KEY,
            student_id INT REFERENCES users(id) ON DELETE CASCADE,
            event_id INT REFERENCES events(id) ON DELETE CASCADE,
            registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(student_id, event_id)
        )
    """)

    q("""
        CREATE TABLE IF NOT EXISTS favorites (
            id SERIAL PRIMARY KEY,
            student_id INT REFERENCES users(id) ON DELETE CASCADE,
            event_id INT REFERENCES events(id) ON DELETE CASCADE,
            UNIQUE(student_id, event_id)
        )
    """)

    q("""
        CREATE TABLE IF NOT EXISTS notices (
            id SERIAL PRIMARY KEY,
            title VARCHAR(160) NOT NULL,
            message TEXT NOT NULL,
            notice_date DATE DEFAULT CURRENT_DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    admin = q("SELECT id FROM users WHERE email=%s", ("admin@campusconnect.com",), True)
    if not admin:
        q(
            """INSERT INTO users(college_id,email,password,role)
               VALUES(%s,%s,%s,'admin')""",
            ("ADMIN001", "admin@campusconnect.com", generate_password_hash("admin123")),
        )

    student = q("SELECT id FROM users WHERE email=%s", ("student@campusconnect.com",), True)
    if not student:
        q(
            """INSERT INTO users(college_id,email,password,role)
               VALUES(%s,%s,%s,'student')""",
            ("BCA2026-001", "student@campusconnect.com", generate_password_hash("student123")),
        )

    # Add a small demo dataset on a fresh project so the UI is immediately visible.
    event_count = q("SELECT COUNT(*) AS c FROM events", one=True)["c"]
    if event_count == 0:
        demo_events = [
            ("Campus Tech Fest 2026", "Technical", "A day of coding, innovation and student projects.",
             "Campus Tech Fest brings coding challenges, project demonstrations and technology activities together for students.",
             "2026-11-12", "10:00", "2026-10-03 09:00", "2026-11-10 18:00", "Main Auditorium", "Computer Department",
             "Open to BCA and eligible college students.", "Carry your college ID. Follow coordinator instructions.", "Report 30 minutes before the event.", "Tech Fest Coordinator", "College Office", "Limited seats; registration is required."),
            ("Annual Sports Meet", "Sports", "Compete, participate and represent your college.",
             "The annual sports meet includes track, team and indoor activities for students across the college.",
             "2026-11-20", "09:00", "2026-10-05 09:00", "2026-11-18 18:00", "College Sports Ground", "Sports Committee",
             "Open to registered college students.", "Bring sports shoes and college ID.", "Report at the registration desk before your event.", "Sports Coordinator", "College Office", "Participants should follow the sports committee schedule."),
            ("Cultural Fest - Rang", "Cultural", "Celebrate music, dance, art and student talent.",
             "Rang is a cultural celebration featuring music, dance, stage performances and creative student activities.",
             "2026-12-02", "11:00", "2026-10-10 09:00", "2026-11-30 18:00", "College Open Stage", "Cultural Committee",
             "All interested students.", "Maintain event discipline and stage timings.", "Participants should reach the backstage area on time.", "Cultural Coordinator", "College Office", "Performance slots are subject to coordinator approval."),
            ("Career Skills Workshop", "Workshop", "Practical guidance for internships, interviews and careers.",
             "A focused workshop covering resume preparation, interview skills, professional communication and career planning.",
             "2026-12-10", "13:00", "2026-10-15 09:00", "2026-12-08 18:00", "Seminar Hall", "Training & Placement Cell",
             "Open to final-year and interested students.", "Bring a notebook and college ID.", "Arrive 15 minutes before the session.", "T&P Coordinator", "Placement Cell", "Seats are limited."),
        ]
        admin_id = q("SELECT id FROM users WHERE email=%s", ("admin@campusconnect.com",), True)["id"]
        for item in demo_events:
            q("""INSERT INTO events(
                title,category,short_description,description,event_date,event_time,
                registration_start,registration_end,venue,organizer,eligibility,rules,
                instructions,contact_person,contact_info,important_notes,created_by
            ) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""", item + (admin_id,))

    notice_count = q("SELECT COUNT(*) AS c FROM notices", one=True)["c"]
    if notice_count == 0:
        q("INSERT INTO notices(title,message,notice_date) VALUES(%s,%s,%s)",
          ("CampusConnect is Live", "Students can now explore upcoming college events and register online.", "2026-10-03"))
        q("INSERT INTO notices(title,message,notice_date) VALUES(%s,%s,%s)",
          ("Carry Your College ID", "Students must carry a valid college ID for event participation.", "2026-10-03"))


def logged_as(role):
    return session.get("role") == role and bool(session.get("uid"))


def event_datetime(event):
    return datetime.combine(event["event_date"], event["event_time"])


def event_status(event):
    now = datetime.now()
    event_dt = event_datetime(event)
    if event_dt <= now:
        return "completed"
    if now < event["registration_start"]:
        return "not_started"
    if now > event["registration_end"]:
        return "closed"
    return "open"


def status_label(status):
    return {
        "open": "Registration Open",
        "not_started": "Registration Not Started",
        "closed": "Registration Closed",
        "completed": "Event Completed",
    }.get(status, "Unknown")


def image_for(category):
    return CATEGORY_IMAGES.get(category, CATEGORY_IMAGES["Other"])


def decorate_events(events):
    for event in events:
        event["status"] = event_status(event)
        event["status_label"] = status_label(event["status"])
        event["image"] = image_for(event.get("category"))
    return events


@app.context_processor
def inject_globals():
    return {
        "logged": bool(session.get("uid")),
        "role": session.get("role"),
        "categories": CATEGORIES,
    }


@app.route("/")
def home():
    events = q("""
        SELECT e.*, COUNT(r.id) AS registration_count
        FROM events e
        LEFT JOIN registrations r ON r.event_id=e.id
        GROUP BY e.id
        ORDER BY e.event_date, e.event_time
        LIMIT 6
    """)
    notices = q("SELECT * FROM notices ORDER BY notice_date DESC, id DESC LIMIT 4")
    decorate_events(events)
    return render_template("home.html", events=events, notices=notices)


@app.route("/student/register", methods=["GET", "POST"])
def student_register():
    if request.method == "POST":
        college_id = request.form.get("college_id", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not college_id or not email or not password:
            flash("Please fill all fields.", "error")
            return redirect(url_for("student_register"))
        if not email.endswith("@gmail.com"):
            flash("Please use a valid Gmail address.", "error")
            return redirect(url_for("student_register"))
        if len(password) < 6:
            flash("Password must contain at least 6 characters.", "error")
            return redirect(url_for("student_register"))

        try:
            q(
                """INSERT INTO users(college_id,email,password,role)
                   VALUES(%s,%s,%s,'student')""",
                (college_id, email, generate_password_hash(password)),
            )
        except IntegrityError:
            flash("College ID or Gmail is already registered.", "error")
            return redirect(url_for("student_register"))

        flash("Registration successful. You can login now.", "success")
        return redirect(url_for("student_login"))

    return render_template("auth.html", mode="Student Registration")


@app.route("/student/login", methods=["GET", "POST"])
def student_login():
    if request.method == "POST":
        login_value = request.form.get("login", "").strip()
        password = request.form.get("password", "")
        user = q(
            """SELECT * FROM users
               WHERE role='student'
               AND (LOWER(email)=LOWER(%s) OR LOWER(college_id)=LOWER(%s))""",
            (login_value, login_value),
            True,
        )
        if user and check_password_hash(user["password"], password):
            session.clear()
            session.update(uid=user["id"], role="student")
            return redirect(url_for("student_dashboard"))
        flash("Invalid College ID/Gmail or password.", "error")

    return render_template("auth.html", mode="Student Login")


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = q(
            """SELECT * FROM users
               WHERE role='admin' AND LOWER(email)=LOWER(%s)""",
            (email,),
            True,
        )
        if user and check_password_hash(user["password"], password):
            session.clear()
            session.update(uid=user["id"], role="admin")
            return redirect(url_for("admin_dashboard"))
        flash("Invalid admin email or password.", "error")

    return render_template("auth.html", mode="Admin Login")


@app.route("/student/dashboard")
def student_dashboard():
    if not logged_as("student"):
        return redirect(url_for("student_login"))

    user = q("SELECT * FROM users WHERE id=%s", (session["uid"],), True)
    events = q("""
        SELECT e.*, COUNT(r.id) AS registration_count
        FROM events e
        LEFT JOIN registrations r ON r.event_id=e.id
        WHERE (e.event_date + e.event_time) > CURRENT_TIMESTAMP
        GROUP BY e.id
        ORDER BY e.event_date, e.event_time
        LIMIT 4
    """)
    notices = q("SELECT * FROM notices ORDER BY notice_date DESC, id DESC LIMIT 4")
    registered_count = q(
        "SELECT COUNT(*) AS c FROM registrations WHERE student_id=%s", (session["uid"],), True
    )["c"]
    favorite_count = q(
        "SELECT COUNT(*) AS c FROM favorites WHERE student_id=%s", (session["uid"],), True
    )["c"]
    decorate_events(events)
    return render_template(
        "student_dashboard.html",
        user=user,
        events=events,
        notices=notices,
        registered_count=registered_count,
        favorite_count=favorite_count,
    )


@app.route("/student/events")
def student_events():
    if not logged_as("student"):
        return redirect(url_for("student_login"))

    search = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    sql = """
        SELECT e.*, COUNT(r.id) AS registration_count,
               EXISTS(
                   SELECT 1 FROM registrations x
                   WHERE x.student_id=%s AND x.event_id=e.id
               ) AS registered,
               EXISTS(
                   SELECT 1 FROM favorites f
                   WHERE f.student_id=%s AND f.event_id=e.id
               ) AS favorite
        FROM events e
        LEFT JOIN registrations r ON r.event_id=e.id
        WHERE (e.title ILIKE %s OR e.short_description ILIKE %s OR e.venue ILIKE %s)
    """
    params = [session["uid"], session["uid"], f"%{search}%", f"%{search}%", f"%{search}%"]
    if category in CATEGORIES:
        sql += " AND e.category=%s"
        params.append(category)
    sql += " GROUP BY e.id ORDER BY e.event_date, e.event_time"

    events = q(sql, params)
    decorate_events(events)
    return render_template("events.html", events=events, search=search, selected_category=category)


@app.route("/student/event/<int:event_id>")
def event_detail(event_id):
    if not logged_as("student"):
        return redirect(url_for("student_login"))

    event = q("SELECT * FROM events WHERE id=%s", (event_id,), True)
    if not event:
        flash("Event not found.", "error")
        return redirect(url_for("student_events"))

    event["status"] = event_status(event)
    event["status_label"] = status_label(event["status"])
    event["image"] = image_for(event["category"])
    event["registered"] = bool(
        q(
            "SELECT id FROM registrations WHERE student_id=%s AND event_id=%s",
            (session["uid"], event_id),
            True,
        )
    )
    event["favorite"] = bool(
        q(
            "SELECT id FROM favorites WHERE student_id=%s AND event_id=%s",
            (session["uid"], event_id),
            True,
        )
    )
    return render_template("event_detail.html", event=event)


@app.route("/student/register-event/<int:event_id>", methods=["POST"])
def register_event(event_id):
    if not logged_as("student"):
        return redirect(url_for("student_login"))

    event = q("SELECT * FROM events WHERE id=%s", (event_id,), True)
    if not event:
        flash("Event not found.", "error")
        return redirect(url_for("student_events"))

    if event_status(event) != "open":
        flash("Registration is not open for this event.", "error")
        return redirect(url_for("event_detail", event_id=event_id))

    try:
        q(
            "INSERT INTO registrations(student_id,event_id) VALUES(%s,%s)",
            (session["uid"], event_id),
        )
        flash("Registration successful!", "success")
    except IntegrityError:
        flash("You are already registered for this event.", "info")

    return redirect(url_for("event_detail", event_id=event_id))


@app.route("/student/favorite/<int:event_id>", methods=["POST"])
def toggle_favorite(event_id):
    if not logged_as("student"):
        return redirect(url_for("student_login"))

    existing = q(
        "SELECT id FROM favorites WHERE student_id=%s AND event_id=%s",
        (session["uid"], event_id),
        True,
    )
    if existing:
        q("DELETE FROM favorites WHERE id=%s", (existing["id"],))
    else:
        try:
            q(
                "INSERT INTO favorites(student_id,event_id) VALUES(%s,%s)",
                (session["uid"], event_id),
            )
        except IntegrityError:
            pass
    return redirect(request.referrer or url_for("student_events"))


@app.route("/student/my-events")
def my_events():
    if not logged_as("student"):
        return redirect(url_for("student_login"))
    rows = q("""
        SELECT e.*, r.registration_date
        FROM registrations r
        JOIN events e ON e.id=r.event_id
        WHERE r.student_id=%s
        ORDER BY e.event_date, e.event_time
    """, (session["uid"],))
    decorate_events(rows)
    return render_template("table.html", title="My Registered Events", rows=rows, table_type="my_events")


@app.route("/student/favorites")
def my_favorites():
    if not logged_as("student"):
        return redirect(url_for("student_login"))
    rows = q("""
        SELECT e.*
        FROM favorites f
        JOIN events e ON e.id=f.event_id
        WHERE f.student_id=%s
        ORDER BY e.event_date, e.event_time
    """, (session["uid"],))
    decorate_events(rows)
    return render_template("events.html", events=rows, search="", selected_category="", favorites_only=True)


@app.route("/student/ranking")
def student_ranking():
    if not logged_as("student"):
        return redirect(url_for("student_login"))
    rows = q("""
        SELECT e.title, e.category, e.event_date, e.venue, COUNT(r.id) AS registrations
        FROM events e
        LEFT JOIN registrations r ON r.event_id=e.id
        GROUP BY e.id
        ORDER BY registrations DESC, e.event_date
    """)
    return render_template("ranking.html", rows=rows, title="Event Ranking")


@app.route("/student/notices")
def student_notices():
    if not logged_as("student"):
        return redirect(url_for("student_login"))
    return render_template("notices.html", notices=q("SELECT * FROM notices ORDER BY notice_date DESC, id DESC"))


@app.route("/student/profile")
def student_profile():
    if not logged_as("student"):
        return redirect(url_for("student_login"))
    user = q("SELECT college_id,email,created_at FROM users WHERE id=%s", (session["uid"],), True)
    return render_template("profile.html", user=user)


def validate_event_form(form):
    keys = [
        "title", "category", "short_description", "description", "event_date", "event_time",
        "registration_start", "registration_end", "venue", "organizer", "eligibility",
        "rules", "instructions", "contact_person", "contact_info", "important_notes",
    ]
    data = {key: form.get(key, "").strip() for key in keys}

    required = ["title", "category", "short_description", "description", "event_date", "event_time",
                "registration_start", "registration_end", "venue", "organizer"]
    if any(not data[key] for key in required):
        return None, "Please fill all required event fields."
    if data["category"] not in CATEGORIES:
        return None, "Invalid event category."

    try:
        event_dt = datetime.strptime(
            f"{data['event_date']} {data['event_time']}", "%Y-%m-%d %H:%M"
        )
        start_dt = datetime.fromisoformat(data["registration_start"])
        end_dt = datetime.fromisoformat(data["registration_end"])
    except ValueError:
        return None, "Please enter valid dates and times."

    if start_dt >= end_dt:
        return None, "Registration start must be before registration end."
    if end_dt >= event_dt:
        return None, "Registration end must be before the event date/time."

    return data, None


def event_form_value(event, field):
    if not event:
        return ""
    value = event.get(field)
    if value is None:
        return ""
    if field == "event_date":
        return value.strftime("%Y-%m-%d")
    if field == "event_time":
        return value.strftime("%H:%M")
    if field in ("registration_start", "registration_end"):
        return value.strftime("%Y-%m-%dT%H:%M")
    return value


@app.route("/admin/dashboard")
def admin_dashboard():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))

    total_students = q("SELECT COUNT(*) AS c FROM users WHERE role='student'", one=True)["c"]
    total_events = q("SELECT COUNT(*) AS c FROM events", one=True)["c"]
    total_registrations = q("SELECT COUNT(*) AS c FROM registrations", one=True)["c"]
    upcoming = q("""
        SELECT COUNT(*) AS c FROM events
        WHERE (event_date + event_time) > CURRENT_TIMESTAMP
    """, one=True)["c"]
    top_events = q("""
        SELECT e.id, e.title, e.category, e.event_date, COUNT(r.id) AS registrations
        FROM events e
        LEFT JOIN registrations r ON r.event_id=e.id
        GROUP BY e.id
        ORDER BY registrations DESC, e.event_date
        LIMIT 5
    """)
    recent = q("""
        SELECT r.registration_date, u.college_id, e.title
        FROM registrations r
        JOIN users u ON u.id=r.student_id
        JOIN events e ON e.id=r.event_id
        ORDER BY r.registration_date DESC
        LIMIT 6
    """)
    return render_template(
        "admin_dashboard.html",
        total_students=total_students,
        total_events=total_events,
        total_registrations=total_registrations,
        upcoming=upcoming,
        top_events=top_events,
        recent=recent,
    )


@app.route("/admin/events")
def admin_events():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    events = q("""
        SELECT e.*, COUNT(r.id) AS registrations
        FROM events e
        LEFT JOIN registrations r ON r.event_id=e.id
        GROUP BY e.id
        ORDER BY e.event_date DESC, e.event_time DESC
    """)
    decorate_events(events)
    return render_template("admin_events.html", events=events)


@app.route("/admin/events/add", methods=["GET", "POST"])
def add_event():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    if request.method == "POST":
        data, error = validate_event_form(request.form)
        if error:
            flash(error, "error")
            return render_template("event_form.html", event=request.form, form_values=dict(request.form))
        q("""
            INSERT INTO events(
                title,category,short_description,description,event_date,event_time,
                registration_start,registration_end,venue,organizer,eligibility,rules,
                instructions,contact_person,contact_info,important_notes,created_by
            ) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, tuple(data.values()) + (session["uid"],))
        flash("Event created successfully.", "success")
        return redirect(url_for("admin_events"))
    return render_template("event_form.html", event=None, form_values={})


@app.route("/admin/events/edit/<int:event_id>", methods=["GET", "POST"])
def edit_event(event_id):
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    event = q("SELECT * FROM events WHERE id=%s", (event_id,), True)
    if not event:
        flash("Event not found.", "error")
        return redirect(url_for("admin_events"))

    if request.method == "POST":
        data, error = validate_event_form(request.form)
        if error:
            flash(error, "error")
            return render_template("event_form.html", event=event, form_values=dict(request.form))
        q("""
            UPDATE events SET title=%s,category=%s,short_description=%s,description=%s,
            event_date=%s,event_time=%s,registration_start=%s,registration_end=%s,
            venue=%s,organizer=%s,eligibility=%s,rules=%s,instructions=%s,
            contact_person=%s,contact_info=%s,important_notes=%s
            WHERE id=%s
        """, tuple(data.values()) + (event_id,))
        flash("Event updated successfully.", "success")
        return redirect(url_for("admin_events"))

    return render_template("event_form.html", event=event, form_values={})


@app.route("/admin/events/delete/<int:event_id>", methods=["POST"])
def delete_event(event_id):
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    q("DELETE FROM events WHERE id=%s", (event_id,))
    flash("Event deleted successfully.", "success")
    return redirect(url_for("admin_events"))


@app.route("/admin/students")
def admin_students():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    search = request.args.get("q", "").strip()
    rows = q("""
        SELECT college_id, email, created_at
        FROM users
        WHERE role='student' AND (college_id ILIKE %s OR email ILIKE %s)
        ORDER BY college_id
    """, (f"%{search}%", f"%{search}%"))
    return render_template("table.html", title="Student Management", rows=rows, table_type="students", search=search)


@app.route("/admin/registrations")
def admin_registrations():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    rows = q("""
        SELECT u.college_id, u.email, e.title, e.category, e.event_date,
               e.venue, r.registration_date
        FROM registrations r
        JOIN users u ON u.id=r.student_id
        JOIN events e ON e.id=r.event_id
        ORDER BY r.registration_date DESC
    """)
    return render_template("table.html", title="Registration Management", rows=rows, table_type="registrations")


@app.route("/admin/ranking")
def admin_ranking():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    rows = q("""
        SELECT e.title,e.category,e.event_date,e.venue,COUNT(r.id) AS registrations
        FROM events e LEFT JOIN registrations r ON r.event_id=e.id
        GROUP BY e.id ORDER BY registrations DESC,e.event_date
    """)
    return render_template("ranking.html", rows=rows, title="Event Ranking")


@app.route("/admin/notices")
def admin_notices():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    return render_template("admin_notices.html", notices=q("SELECT * FROM notices ORDER BY notice_date DESC,id DESC"))


@app.route("/admin/notices/add", methods=["GET", "POST"])
def add_notice():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        message = request.form.get("message", "").strip()
        date = request.form.get("notice_date", "").strip()
        if not title or not message or not date:
            flash("Please fill all notice fields.", "error")
            return redirect(url_for("add_notice"))
        q("INSERT INTO notices(title,message,notice_date) VALUES(%s,%s,%s)", (title, message, date))
        flash("Notice added successfully.", "success")
        return redirect(url_for("admin_notices"))
    return render_template("notice_form.html")


@app.route("/admin/notices/delete/<int:notice_id>", methods=["POST"])
def delete_notice(notice_id):
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    q("DELETE FROM notices WHERE id=%s", (notice_id,))
    flash("Notice deleted successfully.", "success")
    return redirect(url_for("admin_notices"))


@app.route("/admin/reports")
def admin_reports():
    if not logged_as("admin"):
        return redirect(url_for("admin_login"))
    categories = q("SELECT category,COUNT(*) AS count FROM events GROUP BY category ORDER BY count DESC")
    top = q("""
        SELECT e.title,e.category,COUNT(r.id) AS registrations
        FROM events e LEFT JOIN registrations r ON r.event_id=e.id
        GROUP BY e.id ORDER BY registrations DESC
    """)
    return render_template("reports.html", categories=categories, top=top)


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")


if __name__ == "__main__":
    setup()
    app.run(host="127.0.0.1", port=5000, debug=True)

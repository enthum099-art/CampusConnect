# CampusConnect

College Events Management & Student Engagement System

## Stack
Python + Flask + HTML + CSS + PostgreSQL

## PostgreSQL
Database: `campusconnect`
User: `postgres`
Password: `postgres`
Host: `localhost`
Port: `5432`

## Install
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv postgresql postgresql-contrib -y
sudo systemctl enable --now postgresql
sudo -u postgres psql -c "ALTER USER postgres WITH PASSWORD 'postgres';"
sudo -u postgres psql -c "CREATE DATABASE campusconnect;"
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 app.py
```

If the database already exists, ignore the CREATE DATABASE message.

Open: http://127.0.0.1:5000

## Demo login
Admin: `admin@campusconnect.com` / `admin123`
Student: `BCA2026-001` / `student123`

The first run automatically creates the tables and demo accounts.
